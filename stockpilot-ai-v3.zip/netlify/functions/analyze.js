const https = require("https");

const UNIVERSE = [
  {symbol:"AAPL", name:"Apple"},
  {symbol:"MSFT", name:"Microsoft"},
  {symbol:"NVDA", name:"NVIDIA"},
  {symbol:"GOOGL", name:"Alphabet"}
];

const cache = new Map();

function json(statusCode, body){
  return {
    statusCode,
    headers:{
      "Content-Type":"application/json; charset=utf-8",
      "Cache-Control":"no-store"
    },
    body:JSON.stringify(body)
  };
}

function getJson(url){
  return new Promise((resolve,reject)=>{
    const req = https.get(url,{headers:{"User-Agent":"StockPilotAI/3.0"}},res=>{
      let raw="";
      res.setEncoding("utf8");
      res.on("data",chunk=>raw+=chunk);
      res.on("end",()=>{
        if(res.statusCode < 200 || res.statusCode >= 300){
          reject(new Error(`Market data provider returned HTTP ${res.statusCode}.`));
          return;
        }
        try{ resolve(JSON.parse(raw)); }
        catch{ reject(new Error("Market data provider returned invalid JSON.")); }
      });
    });
    req.setTimeout(12000,()=>req.destroy(new Error("Market data request timed out.")));
    req.on("error",reject);
  });
}

async function dailySeries(symbol,key){
  const cached=cache.get(symbol);
  if(cached && cached.expires>Date.now()) return cached.data;

  const url = new URL("https://www.alphavantage.co/query");
  url.searchParams.set("function","TIME_SERIES_DAILY");
  url.searchParams.set("symbol",symbol);
  url.searchParams.set("outputsize","compact");
  url.searchParams.set("apikey",key);

  const data=await getJson(url.toString());
  if(data.Note) throw new Error("The market-data provider is rate-limiting requests. Wait about a minute and try again.");
  if(data["Error Message"]) throw new Error(`Market data error for ${symbol}.`);
  const series=data["Time Series (Daily)"];
  if(!series) throw new Error(`No daily market data was returned for ${symbol}.`);

  const rows=Object.entries(series)
    .sort((a,b)=>b[0].localeCompare(a[0]))
    .map(([date,v])=>({
      date,
      close:Number(v["4. close"]),
      volume:Number(v["5. volume"])
    }))
    .filter(x=>Number.isFinite(x.close) && Number.isFinite(x.volume));

  if(rows.length < 21) throw new Error(`Not enough market history was returned for ${symbol}.`);
  cache.set(symbol,{expires:Date.now()+60000,data:rows});
  return rows;
}

function pct(a,b){ return ((a/b)-1)*100; }
function fmtPct(x){ return `${x>=0?"+":""}${x.toFixed(2)}%`; }

function score(rows,risk,timeframe){
  const latest=rows[0].close;
  const d1=pct(rows[0].close,rows[1].close);
  const d5=pct(rows[0].close,rows[5].close);
  const d20=pct(rows[0].close,rows[20].close);
  const avgVol=rows.slice(1,21).reduce((s,x)=>s+x.volume,0)/20;
  const volRatio=avgVol ? rows[0].volume/avgVol : 1;

  let s=50;
  if(timeframe==="day") s += Math.max(-15,Math.min(15,d1*3)) + Math.max(0,Math.min(10,(volRatio-1)*8));
  if(timeframe==="swing") s += Math.max(-12,Math.min(15,d5*1.8)) + Math.max(-5,Math.min(8,d20*.25));
  if(timeframe==="1-3m") s += Math.max(-10,Math.min(15,d20*.7));
  if(timeframe==="3-12m") s += Math.max(-8,Math.min(15,d20*.8));
  if(timeframe==="1y") s += Math.max(-6,Math.min(15,d20*.5));

  const volatility=Math.abs(d1);
  if(risk==="lower") s -= Math.max(0,Math.min(12,volatility-2));
  if(risk==="higher") s += Math.max(0,Math.min(8,volatility-1));

  return {
    score:Math.max(0,Math.min(100,Math.round(s))),
    d1,d5,d20,volRatio,price:latest
  };
}

exports.handler = async (event)=>{
  if(event.httpMethod==="OPTIONS"){
    return {statusCode:204,headers:{"Access-Control-Allow-Origin":"*"},body:""};
  }
  if(event.httpMethod!=="POST") return json(405,{error:"Use POST for analysis."});

  let input;
  try{ input=JSON.parse(event.body||"{}"); }
  catch{ return json(400,{error:"Invalid request body."}); }

  const amount=Number(input.amount);
  const risk=String(input.risk||"moderate");
  const timeframe=String(input.timeframe||"swing");
  if(!Number.isFinite(amount)||amount<=0) return json(400,{error:"Enter a valid amount greater than $0."});

  const key=process.env.ALPHAVANTAGE_API_KEY;
  if(!key){
    return json(500,{error:"Market-data API key is not configured yet. In Netlify, add ALPHAVANTAGE_API_KEY under Site configuration → Environment variables, then redeploy."});
  }

  try{
    const all=[];
    for(const stock of UNIVERSE){
      const rows=await dailySeries(stock.symbol,key);
      all.push({stock,metrics:score(rows,risk,timeframe)});
    }

    all.sort((a,b)=>b.metrics.score-a.metrics.score);
    const pick=all[0];
    const m=pick.metrics;

    const reasons=[
      `${pick.stock.symbol} has a ${fmtPct(m.d20)} 20-trading-day price change.`,
      `Its latest daily move is ${fmtPct(m.d1)}.`,
      `Recent volume is ${m.volRatio.toFixed(2)}× its 20-day average.`,
      `The score was adjusted for your selected ${risk} risk level and ${timeframe} timeframe.`
    ];

    return json(200,{
      recommendation:{
        symbol:pick.stock.symbol,
        name:pick.stock.name,
        price:m.price,
        asOf:new Date().toISOString(),
        score:pick.metrics.score,
        returns:{
          day:fmtPct(m.d1),
          fiveDay:fmtPct(m.d5),
          twentyDay:fmtPct(m.d20)
        },
        volumeRatio:`${m.volRatio.toFixed(2)}×`,
        reasons,
        summary:`Based on the current data snapshot and the inputs you selected, ${pick.stock.symbol} had the highest transparent match score among the ${UNIVERSE.length} stocks screened.`
      }
    });
  }catch(err){
    return json(502,{error:err.message||"Market data could not be retrieved."});
  }
};

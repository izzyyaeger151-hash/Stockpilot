# StockPilot AI V3

## Deploy
Upload the contents of this folder to Netlify.

V3 fixes the V2 request problem by:
- calling `/api/analyze` through a Netlify redirect
- constructing an absolute same-origin URL in the browser
- adding `netlify.toml` so Netlify knows where the Functions live
- showing useful errors if the Function is missing or returns non-JSON
- using one daily-history request per stock and a short server-side cache

## API key
After deploying, add this Netlify environment variable:

ALPHAVANTAGE_API_KEY = your Alpha Vantage API key

Do not put the key in `index.html`.

Then redeploy the site.

## Important
The recommendation is a transparent data-based match score, not a probability of profit or a guarantee. The site includes informational/educational disclaimers.
